package com.example.xtechads.ads.adunit.adgroup.view

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Declarative wrapper around `AdGroupUnit.showFullScreen(...)` for **any** full-screen format —
 * interstitial, app-open, or rewarded. The format is decided by the placement's `format` in
 * `ads_config.json`, not by this function's name; [onUserEarnedReward] only fires for rewarded ads.
 *
 * Each `placement` maps to one namespace, so swap the ad by repointing its `nameSpace` in config —
 * no namespace argument here. Flip [isRequested] to `true` to show: it shows a loaded ad at once, or
 * loads then shows, or dismisses via [onFailed] + [onDismissRequest] if disabled / no fill. Reset
 * [isRequested] to `false` in [onDismissRequest] to re-arm.
 *
 * ```
 * var requested by remember { mutableStateOf(false) }
 * FullscreenAdObserver(
 *     placement = "reward_recover",
 *     isRequested = requested,
 *     onDismissRequest = { requested = false },
 *     onUserEarnedReward = { grantReward() },
 * )
 * ```
 *
 * @param placement Config placement key (see `placements[]` in `ads_config.json`).
 * @param isRequested Set `true` to request a show; reset to `false` once the flow finishes.
 * @param onDismissRequest Invoked when the flow ends (shown, failed, or cancelled) — reset your flag here.
 * @param onUserEarnedReward Fires only for a completed rewarded ad. No-op for inter/app-open.
 * @param preloadOnEnter Preload the ad when this view first enters composition.
 * @param onAdClosed Called after dismissal; `earned` is `true` only for a completed reward.
 * @param onFailed Called when the placement is disabled or no ad could be shown.
 * @param loading Composable shown while loading before the ad appears.
 */
@Composable
fun FullscreenAdObserver(
    placement: String,
    isRequested: Boolean,
    onDismissRequest: () -> Unit,
    onUserEarnedReward: () -> Unit = {},
    preloadOnEnter: Boolean = false,
    onAdShow: () -> Unit = {},
    onAdClosed: (earned: Boolean) -> Unit = {},
    onFailed: () -> Unit = {},
    loading: @Composable () -> Unit = { FullscreenLoadingDialog() },
) = FullscreenAdObserverImpl(
    placement = placement,
    isRequested = isRequested,
    onDismissRequest = onDismissRequest,
    onUserEarnedReward = onUserEarnedReward,
    preloadOnEnter = preloadOnEnter,
    onAdShow = onAdShow,
    onAdClosed = onAdClosed,
    onFailed = onFailed,
    loading = loading,
)

@Composable
private fun FullscreenLoadingDialog() {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
    ) {
        Box(
            modifier =
                Modifier
                    .size(88.dp)
                    .background(Color.White, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator()
        }
    }
}
