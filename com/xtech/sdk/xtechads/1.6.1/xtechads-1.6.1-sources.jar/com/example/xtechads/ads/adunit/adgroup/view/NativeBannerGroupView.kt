package com.example.xtechads.ads.adunit.adgroup.view

import androidx.annotation.LayoutRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.xtechads.R

/**
 * Renders a **native / banner** ad for a single [placement]. Format, waterfall, layout and reload
 * behaviour are all driven by config; this view just draws whatever the placement resolves to.
 *
 * Each `placement` maps to exactly one namespace in `ads_config.json`, so to swap the ad, repoint
 * the placement's `nameSpace` in config — no namespace argument here. Draws nothing when the
 * placement is missing/disabled; shows a shimmer only during the initial load.
 *
 * ```
 * NativeBannerGroupView(placement = "home_banner", modifier = Modifier.fillMaxWidth())
 * ```
 *
 * @param placement Config placement key (see `placements[]` in `ads_config.json`).
 * @param nameSpace Overrides the namespace the placement resolves to. Leave `null` for the normal
 *   case. Ad units are cached per `placement:nameSpace`, so passing a namespace explicitly is also
 *   how a caller gets a **second, independent unit for the same ads** — useful to preload the next
 *   ad into a spare unit and only swap it in on demand, instead of letting it replace the ad the
 *   user is currently looking at:
 *   ```
 *   // A is on screen, B is warming up; on the next user action, render B and reload A.
 *   NativeBannerGroupView(placement = "language_alt")                              // unit A
 *   NativeBannerGroupView(placement = "language_alt", nameSpace = "language_alt")  // unit B
 *   ```
 * @param defaultNativeLayout Layout when the resolved native entry doesn't override it via config.
 * @param collapsedLayout Layout shown after collapsing a collapsible native ad. Pass `null` to hide
 *   the ad entirely on collapse instead of showing a smaller layout; it reappears on the next reload.
 */
@Composable
fun NativeBannerGroupView(
    modifier: Modifier = Modifier,
    placement: String,
    nameSpace: String? = null,
    screen: String? = null,
    @LayoutRes defaultNativeLayout: Int = R.layout.native_media_ctr_bot_big_filled,
    @LayoutRes collapsedLayout: Int? = R.layout.native_none_media_action_big_filled,
    bindExtra: ((android.view.View) -> Unit)? = null,
) = NativeBannerGroupViewImpl(
    modifier = modifier,
    placement = placement,
    nameSpace = nameSpace,
    screen = screen,
    defaultNativeLayout = defaultNativeLayout,
    collapsedLayout = collapsedLayout,
    bindExtra = bindExtra,
)
