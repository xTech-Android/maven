package com.example.xtechreview

import android.os.Bundle

data class InAppReviewConfig(
    val requestTimeoutMs: Long = 5_000L,
    val onBeforeLaunch: (() -> Unit)? = null,
    val onEvent: ((name: String, params: Bundle?) -> Unit)? = null,
)
