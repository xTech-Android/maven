package com.example.xtechreview.di

import android.content.Context
import com.example.xtechreview.InAppReviewConfig
import com.example.xtechreview.InAppReviewManager
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import org.koin.android.ext.koin.androidApplication
import org.koin.core.module.Module
import org.koin.dsl.module

fun inAppReviewModule(
    config: InAppReviewConfig = InAppReviewConfig(),
    createReviewManager: (Context) -> ReviewManager = ReviewManagerFactory::create,
): Module =
    module {
        single { InAppReviewManager(androidApplication(), config, createReviewManager) }
    }
