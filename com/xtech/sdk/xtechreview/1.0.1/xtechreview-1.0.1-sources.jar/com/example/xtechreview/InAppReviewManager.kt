package com.example.xtechreview

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.google.android.play.core.review.ReviewException
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import timber.log.Timber

class InAppReviewManager(
    context: Context,
    private val config: InAppReviewConfig = InAppReviewConfig(),
    createReviewManager: (Context) -> ReviewManager = ReviewManagerFactory::create,
) {
    init {
        LicenseGuard.verify(context)
    }

    private val reviewManager: ReviewManager? = try {
        createReviewManager(context)
    } catch (e: Exception) {
        Timber.tag(TAG).e(e, "ReviewManagerFactory.create failed, in-app review disabled")
        null
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var reviewInfo: ReviewInfo? = null

    fun preload() = runOnMain {
        val manager = reviewManager ?: return@runOnMain
        try {
            manager.requestReviewFlow().addOnCompleteListener { task ->
                if (task.isSuccessful) reviewInfo = task.result
                else Timber.tag(TAG).w("preload fail: ${task.exception?.message}")
            }
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "preload fail")
        }
    }

    fun launch(
        activity: Activity,
        onFinished: (launched: Boolean) -> Unit = {},
    ) = runOnMain {
        val manager = reviewManager ?: return@runOnMain fail(null, onFinished)
        reviewInfo?.let {
            reviewInfo = null
            return@runOnMain show(manager, activity, it, onFinished)
        }
        var done = false
        val timeout = Runnable {
            done = true
            fail(null, onFinished, TIMEOUT_CODE)
        }
        mainHandler.postDelayed(timeout, config.requestTimeoutMs)
        try {
            manager.requestReviewFlow().addOnCompleteListener { task ->
                if (done) return@addOnCompleteListener
                done = true
                mainHandler.removeCallbacks(timeout)
                if (task.isSuccessful) show(manager, activity, task.result, onFinished)
                else fail(task.exception, onFinished)
            }
        } catch (e: Exception) {
            done = true
            mainHandler.removeCallbacks(timeout)
            fail(e, onFinished)
        }
    }

    private fun show(
        manager: ReviewManager,
        activity: Activity,
        info: ReviewInfo,
        onFinished: (launched: Boolean) -> Unit,
    ) {
        if (activity.isFinishing || activity.isDestroyed) return finish(onFinished, false)
        try {
            safely { config.onBeforeLaunch?.invoke() }
            track("in_app_review_launch")
            manager.launchReviewFlow(activity, info).addOnCompleteListener { finish(onFinished, true) }
        } catch (e: Exception) {
            fail(e, onFinished)
        }
    }

    private fun fail(
        e: Exception?,
        onFinished: (launched: Boolean) -> Unit,
        code: Int = (e as? ReviewException)?.errorCode ?: UNKNOWN_CODE,
    ) {
        Timber.tag(TAG).e("launch fail: code=$code ${e?.message}")
        track("in_app_review_fail", code)
        finish(onFinished, false)
    }

    private fun finish(onFinished: (launched: Boolean) -> Unit, launched: Boolean) =
        safely { onFinished(launched) }

    private fun track(name: String, code: Int? = null) =
        safely { config.onEvent?.invoke(name, code?.let { Bundle().apply { putInt("code", it) } }) }

    private fun safely(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "app callback threw")
        }
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
    }

    private companion object {
        const val TAG = "InAppReviewManager"
        const val UNKNOWN_CODE = -1
        const val TIMEOUT_CODE = -2
    }
}
