package com.example.xtechbilling

import android.app.Activity
import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.Snapshot
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import kotlin.coroutines.resume
import kotlin.time.Duration.Companion.milliseconds

class BillingManager(
    private val app: Application,
    private val config: BillingConfig,
) : PurchasesUpdatedListener {

    private val scope =
        CoroutineScope(
            SupervisorJob() + Dispatchers.IO +
                CoroutineExceptionHandler { _, throwable -> Timber.tag(TAG).e(throwable, "billing: uncaught") },
        )
    private val pref = BillingPref(app)
    private val connectMutex = Mutex()
    private val purchasesMutex = Mutex()

    private val _initState = MutableStateFlow(StateInit.None)
    val initStateFlow: StateFlow<StateInit> = _initState.asStateFlow()
    val initState: StateInit
        get() = _initState.value

    private val _fetchState = MutableStateFlow(StateFetch.None)
    val fetchStateFlow: StateFlow<StateFetch> = _fetchState.asStateFlow()
    val fetchState: StateFetch
        get() = _fetchState.value

    private val _buyState = MutableStateFlow(StateBuy.None)
    val buyStateFlow: StateFlow<StateBuy> = _buyState.asStateFlow()
    val buyState: StateBuy
        get() = _buyState.value

    var isPurchased by mutableStateOf(pref.isPurchased)
        private set

    private val _packages = mutableStateListOf<BillingPackage>()
    val packages: List<BillingPackage>
        get() = _packages

    private val _purchases = mutableStateListOf<Purchase>()
    val purchases: List<Purchase>
        get() = _purchases

    val canShowIAP: Boolean
        get() = _packages.isNotEmpty() && !isPurchased

    val purchasedProductIds: Set<String>
        get() = _purchases.flatMap { it.products }.toSet()

    private class PendingPurchase(
        val productId: String,
        val onError: (error: BillingError, userCancelled: Boolean) -> Unit,
        val onSuccess: (purchase: Purchase) -> Unit,
    )

    @Volatile
    private var pendingPurchase: PendingPurchase? = null

    private val client: BillingClient =
        BillingClient
            .newBuilder(app)
            .setListener(this)
            .enablePendingPurchases(
                PendingPurchasesParams
                    .newBuilder()
                    .enableOneTimeProducts()
                    .enablePrepaidPlans()
                    .build(),
            ).enableAutoServiceReconnection()
            .build()

    private val isConnected: Boolean
        get() = client.connectionState == BillingClient.ConnectionState.CONNECTED

    init {
        LicenseGuard.verify(app)
        initSDK()
        observeAppLifecycle()
    }

    private fun initSDK() {
        val start = System.currentTimeMillis()
        val handler =
            CoroutineExceptionHandler { _, throwable ->
                Timber.tag(TAG).e(throwable, "initSDK: error")
                if (_fetchState.value == StateFetch.Fetching) _fetchState.value = StateFetch.Fail
                _initState.value = StateInit.Done
                config.onInitDone?.invoke(start, false)
            }
        scope.launch(handler) {
            _initState.value = StateInit.Checking
            val cachedExpiration = pref.purchaseExpirationTime
            val now = System.currentTimeMillis()
            if (cachedExpiration > now) {
                Timber.tag(TAG).d("initSDK: cache valid until $cachedExpiration, skip fetch")
                _initState.value = StateInit.Done
                config.onInitDone?.invoke(start, true)
                return@launch
            }
            val connected = ensureConnected()
            if (connected) {
                when {
                    cachedExpiration == 0L && !isPurchased -> {
                        Timber.tag(TAG).d("initSDK: never purchased, skip fetch")
                        fetchPackages()
                    }

                    isPurchased -> {
                        refreshPurchases()
                        fetchPackagesIfNeeded()
                    }

                    else ->
                        listOf(
                            async { refreshPurchases() },
                            async { fetchPackages() },
                        ).awaitAll()
                }
            } else {
                _fetchState.value = StateFetch.Fail
            }
            Timber.tag(TAG).d(
                "initSDK: purchased=$isPurchased packages=${_packages.size} " +
                    "fetch=${_fetchState.value} take=${System.currentTimeMillis() - start}ms",
            )
            _initState.value = StateInit.Done
            config.onInitDone?.invoke(start, connected)
        }
    }

    private fun observeAppLifecycle() {
        scope.launch(Dispatchers.Main) {
            ProcessLifecycleOwner.get().lifecycle.addObserver(
                object : DefaultLifecycleObserver {
                    override fun onStart(owner: LifecycleOwner) {
                        if (_initState.value != StateInit.Done) return
                        if (pref.purchaseExpirationTime > System.currentTimeMillis()) return
                        scope.launch {
                            if (!ensureConnected()) return@launch
                            refreshPurchases()
                            fetchPackagesIfNeeded()
                        }
                    }
                },
            )
        }
    }

    private suspend fun ensureConnected(): Boolean =
        connectMutex.withLock {
            if (isConnected) return true
            val connected =
                withTimeoutOrNull(config.connectTimeoutMs.milliseconds) {
                    while (client.connectionState == BillingClient.ConnectionState.CONNECTING) delay(100)
                    if (isConnected) true else connect()
                } ?: false
            Timber.tag(TAG).d("ensureConnected: connected=$connected state=${client.connectionState}")
            connected
        }

    private suspend fun connect(): Boolean =
        suspendCancellableCoroutine { continuation ->
            Timber.tag(TAG).d("connect: startConnection")
            client.startConnection(
                object : BillingClientStateListener {
                    override fun onBillingSetupFinished(result: BillingResult) {
                        Timber.tag(TAG).d("onBillingSetupFinished: ${result.responseCode} ${result.debugMessage}")
                        if (continuation.isActive) {
                            continuation.resume(result.responseCode == BillingClient.BillingResponseCode.OK)
                        }
                    }

                    override fun onBillingServiceDisconnected() {
                        Timber.tag(TAG).w("onBillingServiceDisconnected")
                        if (continuation.isActive) continuation.resume(false)
                    }
                },
            )
        }

    fun refetchPackages() {
        scope.launch {
            if (ensureConnected()) fetchPackages() else _fetchState.value = StateFetch.Fail
        }
    }

    private suspend fun fetchPackagesIfNeeded() {
        if (isPurchased || _fetchState.value == StateFetch.Done) return
        fetchPackages()
    }

    private suspend fun fetchPackages() {
        if (config.products.isEmpty()) {
            _fetchState.value = StateFetch.Done
            return
        }
        _fetchState.value = StateFetch.Fetching
        val result =
            withTimeoutOrNull(config.fetchTimeoutMs.milliseconds) {
                val subs =
                    queryProductDetails(
                        config.products.filter { it.type == ProductType.SUBS },
                        BillingClient.ProductType.SUBS,
                    )
                val inApp =
                    queryProductDetails(
                        config.products.filter { it.type == ProductType.INAPP },
                        BillingClient.ProductType.INAPP,
                    )
                subs to inApp
            }
        val subs = result?.first
        val inApp = result?.second
        val fetched = subs.orEmpty() + inApp.orEmpty()
        val complete = subs != null && inApp != null
        if (complete || fetched.isNotEmpty()) {
            _packages.replaceAll(fetched.flatMap { BillingPackage.from(it) })
        }
        _fetchState.value = if (complete) StateFetch.Done else StateFetch.Fail
        Timber.tag(TAG).d("fetchPackages: state=${_fetchState.value} packages=${_packages.size}")
        _packages.forEach {
            Timber.tag(TAG).d(
                "package: ${it.productId} base=${it.basePlanId} offer=${it.offerId} type=${it.packageType} " +
                    "price=${it.formattedPrice} period=${it.period} trial=${it.trialPeriod}",
            )
        }
    }

    private suspend fun queryProductDetails(
        products: List<BillingProduct>,
        type: String,
    ): List<ProductDetails>? {
        if (products.isEmpty()) return emptyList()
        val params =
            QueryProductDetailsParams
                .newBuilder()
                .setProductList(
                    products.map {
                        QueryProductDetailsParams.Product
                            .newBuilder()
                            .setProductId(it.id)
                            .setProductType(type)
                            .build()
                    },
                ).build()
        return suspendCancellableCoroutine { continuation ->
            client.queryProductDetailsAsync(params) { result, details ->
                if (!continuation.isActive) return@queryProductDetailsAsync
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    details.unfetchedProductList.forEach {
                        Timber.tag(TAG).w("queryProductDetails: unfetched ${it.productId} status=${it.statusCode}")
                    }
                    continuation.resume(details.productDetailsList)
                } else {
                    Timber.tag(TAG).e("queryProductDetails($type): ${result.responseCode} ${result.debugMessage}")
                    continuation.resume(null)
                }
            }
        }
    }

    suspend fun refreshPurchases(): Boolean {
        val subs = queryPurchases(BillingClient.ProductType.SUBS)
        val inApp = queryPurchases(BillingClient.ProductType.INAPP)
        if (subs == null && inApp == null) return isPurchased
        applyPurchases(subs.orEmpty() + inApp.orEmpty(), replace = subs != null && inApp != null)
        cacheExpiration()
        return isPurchased
    }

    private fun cacheExpiration() {
        scope.launch {
            val expiration = _purchases.maxOfOrNull { expirationOf(it) } ?: 0L
            pref.purchaseExpirationTime = expiration
            Timber.tag(TAG).d("cacheExpiration: $expiration")
        }
    }

    private suspend fun expirationOf(purchase: Purchase): Long {
        val productId = purchase.products.firstOrNull() ?: return 0L
        val product = config.products.firstOrNull { it.id == productId } ?: return 0L
        if (product.type == ProductType.INAPP) return FAR_FUTURE_EXPIRATION
        val packages =
            _packages.filter { it.productId == productId }.ifEmpty {
                withTimeoutOrNull(config.fetchTimeoutMs.milliseconds) {
                    queryProductDetails(listOf(product), BillingClient.ProductType.SUBS)
                }?.flatMap { BillingPackage.from(it) }.orEmpty()
            }
        val shortest = packages.minOfOrNull { it.durationDays } ?: return 0L
        return purchase.purchaseTime + shortest * DAY_MS
    }

    private suspend fun queryPurchases(type: String): List<Purchase>? {
        val result =
            withTimeoutOrNull(config.queryTimeoutMs.milliseconds) {
                suspendCancellableCoroutine { continuation ->
                    client.queryPurchasesAsync(
                        QueryPurchasesParams.newBuilder().setProductType(type).build(),
                    ) { billingResult, list ->
                        if (!continuation.isActive) return@queryPurchasesAsync
                        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                            continuation.resume(list)
                        } else {
                            Timber.tag(TAG).e("queryPurchases($type): ${billingResult.responseCode} ${billingResult.debugMessage}")
                            continuation.resume(null)
                        }
                    }
                }
            }
        if (result == null) Timber.tag(TAG).e("queryPurchases($type): timeout after ${config.queryTimeoutMs}ms")
        return result
    }

    private fun isConsumable(purchase: Purchase): Boolean =
        purchase.products.any { pid -> config.products.any { it.id == pid && it.consumable } }

    private suspend fun applyPurchases(
        incoming: List<Purchase>,
        replace: Boolean,
    ) = purchasesMutex.withLock {
        val purchased = incoming.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }
        // Consumable (coin pack): grant + consume, KHÔNG acknowledge, KHÔNG tính vào isPurchased.
        val (consumables, entitlements) = purchased.partition { isConsumable(it) }
        consumables.forEach { handleConsumable(it) }
        entitlements.filter { !it.isAcknowledged }.forEach { acknowledge(it) }
        val merged =
            if (replace) {
                entitlements
            } else {
                _purchases.filter { old -> entitlements.none { it.purchaseToken == old.purchaseToken } } + entitlements
            }
        Snapshot.withMutableSnapshot {
            _purchases.replaceAll(merged)
            isPurchased = merged.isNotEmpty()
        }
        pref.isPurchased = isPurchased
        Timber.tag(TAG).d("applyPurchases: active=${merged.flatMap { it.products }} consumable=${consumables.flatMap { it.products }}")
    }

    /** Grant (idempotent, app lo qua orderId) rồi consume để user mua lại được. Fire pending nếu là gói vừa mua. */
    private suspend fun handleConsumable(purchase: Purchase) {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return
        withContext(Dispatchers.Main) { config.onConsume?.invoke(purchase) }
        val consumed = consume(purchase)
        Timber.tag(TAG).d("handleConsumable ${purchase.products}: consumed=$consumed")
        if (pendingPurchase?.productId?.let { it in purchase.products } == true) finishBuySuccess(purchase)
    }

    private suspend fun consume(purchase: Purchase): Boolean {
        val result =
            withTimeoutOrNull(config.queryTimeoutMs.milliseconds) {
                suspendCancellableCoroutine { continuation ->
                    client.consumeAsync(
                        ConsumeParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build(),
                    ) { billingResult, _ ->
                        Timber.tag(TAG).d("consume ${purchase.products}: ${billingResult.responseCode} ${billingResult.debugMessage}")
                        if (continuation.isActive) {
                            continuation.resume(billingResult.responseCode == BillingClient.BillingResponseCode.OK)
                        }
                    }
                }
            }
        if (result == null) Timber.tag(TAG).e("consume ${purchase.products}: timeout after ${config.queryTimeoutMs}ms")
        return result ?: false
    }

    private suspend fun acknowledge(purchase: Purchase): Boolean {
        val result =
            withTimeoutOrNull(config.queryTimeoutMs.milliseconds) {
                suspendCancellableCoroutine { continuation ->
                    client.acknowledgePurchase(
                        AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build(),
                    ) { billingResult ->
                        Timber.tag(TAG).d("acknowledge ${purchase.products}: ${billingResult.responseCode} ${billingResult.debugMessage}")
                        if (continuation.isActive) {
                            continuation.resume(billingResult.responseCode == BillingClient.BillingResponseCode.OK)
                        }
                    }
                }
            }
        if (result == null) Timber.tag(TAG).e("acknowledge ${purchase.products}: timeout after ${config.queryTimeoutMs}ms")
        return result ?: false
    }

    private fun <T> SnapshotStateList<T>.replaceAll(items: List<T>) =
        Snapshot.withMutableSnapshot {
            clear()
            addAll(items)
        }

    fun purchaseWith(
        activity: Activity,
        packageItem: BillingPackage,
        onError: (error: BillingError, userCancelled: Boolean) -> Unit,
        onSuccess: (purchase: Purchase) -> Unit,
    ) {
        if (_buyState.value == StateBuy.Buying) {
            onError(BillingError.inProgress(), false)
            return
        }
        _buyState.value = StateBuy.Buying
        pendingPurchase = PendingPurchase(packageItem.productId, onError, onSuccess)
        scope.launch {
            try {
                if (!ensureConnected()) {
                    finishBuyError(BillingError.disconnected())
                    return@launch
                }
                val params =
                    BillingFlowParams
                        .newBuilder()
                        .setProductDetailsParamsList(
                            listOf(
                                BillingFlowParams.ProductDetailsParams
                                    .newBuilder()
                                    .setProductDetails(packageItem.productDetails)
                                    .apply { packageItem.offerToken?.let { setOfferToken(it) } }
                                    .build(),
                            ),
                        ).build()
                val result = withContext(Dispatchers.Main) { client.launchBillingFlow(activity, params) }
                Timber.tag(TAG).d("launchBillingFlow ${packageItem.productId}: ${result.responseCode} ${result.debugMessage}")
                when (result.responseCode) {
                    BillingClient.BillingResponseCode.OK -> Unit
                    BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> handleAlreadyOwned()
                    else -> finishBuyError(BillingError.from(result))
                }
            } catch (throwable: Throwable) {
                Timber.tag(TAG).e(throwable, "purchaseWith: error")
                finishBuyError(BillingError(BillingClient.BillingResponseCode.ERROR, throwable.message.orEmpty()))
            }
        }
    }

    override fun onPurchasesUpdated(
        result: BillingResult,
        purchases: List<Purchase>?,
    ) {
        Timber.tag(TAG).d("onPurchasesUpdated: ${result.responseCode} ${result.debugMessage} size=${purchases?.size}")
        scope.launch {
            when (result.responseCode) {
                BillingClient.BillingResponseCode.OK -> {
                    val list = purchases.orEmpty()
                    applyPurchases(list, replace = false)
                    cacheExpiration()
                    when {
                        list.any { it.purchaseState == Purchase.PurchaseState.PURCHASED } ->
                            finishBuySuccess(list.first { it.purchaseState == Purchase.PurchaseState.PURCHASED })

                        list.any { it.purchaseState == Purchase.PurchaseState.PENDING } ->
                            finishBuyError(BillingError.pending())

                        else -> finishBuyError(BillingError.from(result))
                    }
                }

                BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> handleAlreadyOwned()

                else -> finishBuyError(BillingError.from(result))
            }
        }
    }

    private suspend fun handleAlreadyOwned() {
        refreshPurchases()
        val productId = pendingPurchase?.productId
        val owned =
            _purchases.firstOrNull { productId != null && productId in it.products }
                ?: _purchases.firstOrNull()
        if (owned != null) {
            finishBuySuccess(owned)
        } else {
            finishBuyError(BillingError(BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED, "already owned but not found"))
        }
    }

    private suspend fun finishBuySuccess(purchase: Purchase) {
        val callback = pendingPurchase ?: return
        pendingPurchase = null
        _buyState.value = StateBuy.Success
        Timber.tag(TAG).d("purchase success: ${purchase.products}")
        withContext(Dispatchers.Main) { callback.onSuccess(purchase) }
    }

    private suspend fun finishBuyError(error: BillingError) {
        val callback = pendingPurchase ?: return
        pendingPurchase = null
        _buyState.value = StateBuy.Cancel
        Timber.tag(TAG).e("purchase fail: $error")
        withContext(Dispatchers.Main) { callback.onError(error, error.isUserCancelled) }
    }

    fun purchaseRestore(
        onError: (error: BillingError) -> Unit,
        onSuccess: (purchases: List<Purchase>) -> Unit,
    ) {
        if (_buyState.value == StateBuy.Buying) {
            onError(BillingError.inProgress())
            return
        }
        _buyState.value = StateBuy.Buying
        scope.launch {
            val error =
                try {
                    val connected = ensureConnected()
                    when {
                        !connected -> BillingError.disconnected()
                        refreshPurchases() -> null
                        else -> BillingError.notOwned()
                    }
                } catch (throwable: Throwable) {
                    Timber.tag(TAG).e(throwable, "purchaseRestore: error")
                    BillingError(BillingClient.BillingResponseCode.ERROR, throwable.message.orEmpty())
                }
            if (error == null) {
                _buyState.value = StateBuy.Success
                withContext(Dispatchers.Main) { onSuccess(_purchases.toList()) }
            } else {
                _buyState.value = StateBuy.Cancel
                Timber.tag(TAG).e("restore fail: $error")
                withContext(Dispatchers.Main) { onError(error) }
            }
        }
    }

    fun resetBuyState() {
        pendingPurchase = null
        _buyState.value = StateBuy.None
    }

    fun resetFetchState() {
        _fetchState.value = StateFetch.None
    }

    companion object {
        private const val TAG = "BillingManager"
        private const val DAY_MS = 24 * 60 * 60 * 1000L
        private const val FAR_FUTURE_EXPIRATION = Long.MAX_VALUE / 2

        fun isPurchasedCached(context: Context): Boolean = BillingPref(context).isPurchased
    }
}
