package com.example.xtechbilling

import com.android.billingclient.api.Purchase

data class BillingProduct(
    val id: String,
    val type: ProductType = ProductType.SUBS,
    val consumable: Boolean = false,
)

data class BillingConfig(
    val products: List<BillingProduct>,
    val connectTimeoutMs: Long = 10_000L,
    val fetchTimeoutMs: Long = 20_000L,
    val queryTimeoutMs: Long = 10_000L,
    val onInitDone: ((startTime: Long, success: Boolean) -> Unit)? = null,
    val onConsume: ((purchase: Purchase) -> Unit)? = null,
)
