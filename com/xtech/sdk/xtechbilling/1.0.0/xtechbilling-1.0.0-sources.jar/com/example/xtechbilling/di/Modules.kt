package com.example.xtechbilling.di

import com.example.xtechbilling.BillingConfig
import com.example.xtechbilling.BillingManager
import org.koin.android.ext.koin.androidApplication
import org.koin.core.module.Module
import org.koin.dsl.module

fun billingModule(config: BillingConfig): Module =
    module {
        single { BillingManager(androidApplication(), config) }
    }
