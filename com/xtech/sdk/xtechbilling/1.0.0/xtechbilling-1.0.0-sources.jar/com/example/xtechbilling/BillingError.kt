package com.example.xtechbilling

import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingResult

data class BillingError(
    val code: Int,
    val message: String,
) {
    val isUserCancelled: Boolean
        get() = code == BillingClient.BillingResponseCode.USER_CANCELED

    val isPending: Boolean
        get() = code == PENDING

    val name: String
        get() =
            when (code) {
                BillingClient.BillingResponseCode.OK -> "OK"
                BillingClient.BillingResponseCode.USER_CANCELED -> "USER_CANCELED"
                BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE -> "SERVICE_UNAVAILABLE"
                BillingClient.BillingResponseCode.BILLING_UNAVAILABLE -> "BILLING_UNAVAILABLE"
                BillingClient.BillingResponseCode.ITEM_UNAVAILABLE -> "ITEM_UNAVAILABLE"
                BillingClient.BillingResponseCode.DEVELOPER_ERROR -> "DEVELOPER_ERROR"
                BillingClient.BillingResponseCode.ERROR -> "ERROR"
                BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> "ITEM_ALREADY_OWNED"
                BillingClient.BillingResponseCode.ITEM_NOT_OWNED -> "ITEM_NOT_OWNED"
                BillingClient.BillingResponseCode.NETWORK_ERROR -> "NETWORK_ERROR"
                BillingClient.BillingResponseCode.SERVICE_DISCONNECTED -> "SERVICE_DISCONNECTED"
                BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED -> "FEATURE_NOT_SUPPORTED"
                BillingClient.BillingResponseCode.SERVICE_TIMEOUT -> "SERVICE_TIMEOUT"
                PENDING -> "PENDING"
                IN_PROGRESS -> "IN_PROGRESS"
                else -> "UNKNOWN_$code"
            }

    companion object {
        const val PENDING = 1000
        const val IN_PROGRESS = 1001

        fun from(result: BillingResult): BillingError =
            BillingError(result.responseCode, result.debugMessage)

        fun pending(): BillingError = BillingError(PENDING, "purchase pending")

        fun inProgress(): BillingError = BillingError(IN_PROGRESS, "another purchase in progress")

        fun disconnected(): BillingError =
            BillingError(BillingClient.BillingResponseCode.SERVICE_DISCONNECTED, "billing not connected")

        fun notOwned(): BillingError =
            BillingError(BillingClient.BillingResponseCode.ITEM_NOT_OWNED, "no active purchase")
    }
}
