package com.example.xtechbilling

import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.ProductDetails
import java.text.DecimalFormat
import java.util.Currency

data class BillingPackage(
    val productId: String,
    val type: ProductType,
    val packageType: PackageType,
    val basePlanId: String?,
    val offerId: String?,
    val offerToken: String?,
    val priceMicros: Long,
    val currencyCode: String,
    val formattedPrice: String,
    val period: String?,
    val trialPeriod: String?,
    val productDetails: ProductDetails,
) {
    val hasFreeTrial: Boolean
        get() = trialPeriod != null

    val trialDays: Int?
        get() = trialPeriod?.let { isoPeriodToDays(it) }

    val durationDays: Int
        get() = when (packageType) {
            PackageType.LIFETIME -> -1
            else -> period?.let { isoPeriodToDays(it) } ?: 0
        }

    val currencySymbol: String
        get() = runCatching { Currency.getInstance(currencyCode).symbol }.getOrDefault(currencyCode)

    fun priceValue(): String = DecimalFormat("#,##0.00").format(priceMicros / 1_000_000.0)

    fun priceText(discount: Long = 0L, percent: Float = 1f): String {
        val base = if (percent == 1f) priceMicros.toDouble() else priceMicros / percent.toDouble()
        val price = base * 100.0 / (100 - discount).coerceAtLeast(1)
        var text = DecimalFormat("#,##0.00").format(price / 1_000_000.0)
        text = text.removeSuffix(".00")
        if (text.contains('.') && text.endsWith("0")) text = text.dropLast(1)
        return currencySymbol + text
    }

    companion object {
        fun from(details: ProductDetails): List<BillingPackage> =
            when (details.productType) {
                BillingClient.ProductType.SUBS -> fromSubs(details)
                else -> fromInApp(details)
            }

        private fun fromSubs(details: ProductDetails): List<BillingPackage> {
            val offers = details.subscriptionOfferDetails.orEmpty()
            return offers.groupBy { it.basePlanId }.mapNotNull { (basePlanId, planOffers) ->
                val base = planOffers.firstOrNull { it.pricingPhases.pricingPhaseList.size == 1 }
                    ?: planOffers.firstOrNull { it.offerId == null }
                    ?: planOffers.first()
                val trial = planOffers.firstOrNull { offer ->
                    offer.pricingPhases.pricingPhaseList.any { it.priceAmountMicros == 0L }
                }
                val chosen = trial ?: base
                val recurring = chosen.pricingPhases.pricingPhaseList.lastOrNull() ?: return@mapNotNull null
                val trialPhase = trial?.pricingPhases?.pricingPhaseList?.firstOrNull { it.priceAmountMicros == 0L }
                BillingPackage(
                    productId = details.productId,
                    type = ProductType.SUBS,
                    packageType = periodToPackageType(recurring.billingPeriod),
                    basePlanId = basePlanId,
                    offerId = chosen.offerId,
                    offerToken = chosen.offerToken,
                    priceMicros = recurring.priceAmountMicros,
                    currencyCode = recurring.priceCurrencyCode,
                    formattedPrice = recurring.formattedPrice,
                    period = recurring.billingPeriod,
                    trialPeriod = trialPhase?.billingPeriod,
                    productDetails = details,
                )
            }
        }

        private fun fromInApp(details: ProductDetails): List<BillingPackage> {
            val offer = details.oneTimePurchaseOfferDetailsList?.firstOrNull()
                ?: details.oneTimePurchaseOfferDetails
                ?: return emptyList()
            return listOf(
                BillingPackage(
                    productId = details.productId,
                    type = ProductType.INAPP,
                    packageType = PackageType.LIFETIME,
                    basePlanId = null,
                    offerId = offer.offerId,
                    offerToken = offer.offerToken,
                    priceMicros = offer.priceAmountMicros,
                    currencyCode = offer.priceCurrencyCode,
                    formattedPrice = offer.formattedPrice,
                    period = null,
                    trialPeriod = null,
                    productDetails = details,
                ),
            )
        }

        fun periodToPackageType(iso: String): PackageType =
            when (iso) {
                "P1W", "P7D" -> PackageType.WEEKLY
                "P1M", "P4W", "P30D" -> PackageType.MONTHLY
                "P3M" -> PackageType.THREE_MONTH
                "P6M" -> PackageType.SIX_MONTH
                "P1Y", "P12M", "P365D" -> PackageType.ANNUAL
                else -> PackageType.UNKNOWN
            }

        fun isoPeriodToDays(iso: String): Int? {
            val match = Regex("""P(\d+)([DWMY])""").matchEntire(iso) ?: return null
            val n = match.groupValues[1].toIntOrNull() ?: return null
            return when (match.groupValues[2]) {
                "D" -> n
                "W" -> n * 7
                "M" -> n * 30
                "Y" -> n * 365
                else -> null
            }
        }
    }
}
