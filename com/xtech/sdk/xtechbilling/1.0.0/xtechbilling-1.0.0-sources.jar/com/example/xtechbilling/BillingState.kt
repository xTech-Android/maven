package com.example.xtechbilling

enum class StateInit { None, Checking, Done }

enum class StateFetch { None, Fetching, Fail, Done }

enum class StateBuy { None, Buying, Cancel, Success }

enum class ProductType { SUBS, INAPP }

enum class PackageType { WEEKLY, MONTHLY, THREE_MONTH, SIX_MONTH, ANNUAL, LIFETIME, UNKNOWN }
