package com.example.xtechcore.remoteconfig

// Tham so fetch cua RC. Tach rieng de core khong phai biet AppConfig (co field rieng cua ads).
data class RemoteConfigOptions(
    val timeoutSeconds: Long = 5,
    val minimumFetchIntervalSeconds: Long = 3600,
    val maxRetry: Int = 5,
    val retryDelayMs: Long = 100,
    // Chi ghi key doi gia tri, gom 1 apply(): apply() thua de lai QueuedWork, receiver finish dung luc do
    // gay crash "Broadcast already finished" tren vivo Android 12-13.
    val writeChangedOnly: Boolean = false,
)
