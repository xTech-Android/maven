package com.example.xtechcore.remoteconfig

// Tham so fetch cua RC. Tach rieng de core khong phai biet AppConfig (co field rieng cua ads).
// @JvmOverloads giu constructor 4 tham so ma xtechads <= 1.9.3 da compile vao: thieu la NoSuchMethodError luc khoi dong.
// Them field moi thi chi them o CUOI, co default.
data class RemoteConfigOptions @JvmOverloads constructor(
    val timeoutSeconds: Long = 5,
    val minimumFetchIntervalSeconds: Long = 3600,
    val maxRetry: Int = 5,
    val retryDelayMs: Long = 100,
    // Chi ghi key doi gia tri, gom 1 apply(): apply() thua de lai QueuedWork, receiver finish dung luc do
    // gay crash "Broadcast already finished" tren vivo Android 12-13.
    val writeChangedOnly: Boolean = false,
)
