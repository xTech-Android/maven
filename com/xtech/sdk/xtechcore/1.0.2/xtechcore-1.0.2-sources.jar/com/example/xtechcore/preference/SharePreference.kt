package com.example.xtechcore.preference

import android.app.Application
import android.content.Context
import androidx.core.content.edit
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import timber.log.Timber
import kotlin.reflect.KProperty

// Doi gia tri sang dang luu giong put() (kieu khac -> JSON Gson) roi so voi prefs hien tai.
// equals() phan biet ca kieu: Long 1 khac Float 1f khac String "1", nen key doi kieu van duoc ghi.
internal fun changedEntries(
    current: Map<String, *>,
    incoming: Map<String, Any>,
): Map<String, Any> {
    val changed = LinkedHashMap<String, Any>()
    for ((key, value) in incoming) {
        val stored: Any =
            when (value) {
                is String, is Boolean, is Float, is Int, is Long -> value
                else -> Gson().toJson(value)
            }
        if (current[key] != stored) changed[key] = stored
    }
    return changed
}

open class SharePreference(
    private val app: Application,
) {
    protected val TAG: String
        get() = this::class.java.simpleName

    private val mSharedPreferences = app.getSharedPreferences(app.packageName, Context.MODE_PRIVATE)

    fun getInt(
        name: String,
        defaultInt: Int,
    ): Int = mSharedPreferences.getInt(name, defaultInt)

    fun getBoolean(
        name: String,
        defaultBoolean: Boolean,
    ): Boolean = mSharedPreferences.getBoolean(name, defaultBoolean)

    fun getString(
        name: String,
        defaultString: String,
    ): String = mSharedPreferences.getString(name, defaultString) ?: defaultString

    fun getFloat(
        name: String,
        defaultFloat: Float,
    ): Float = mSharedPreferences.getFloat(name, defaultFloat)

    fun getLong(
        name: String,
        defaultValue: Long,
    ): Long = mSharedPreferences.getLong(name, defaultValue)

    fun <T> put(
        key: String,
        data: T,
    ) {
        mSharedPreferences.edit {
            when (data) {
                is String -> {
                    putString(key, data)
                }

                is Boolean -> {
                    putBoolean(key, data)
                }

                is Float -> {
                    putFloat(key, data)
                }

                is Int -> {
                    putInt(key, data)
                }

                is Long -> {
                    putLong(key, data)
                }

                else -> {
                    val jsonData = Gson().toJson(data)
                    putString(key, jsonData)
                }
            }
        }
    }

    // Ghi gop trong 1 apply(), bo qua key trung ca gia tri lan kieu. Khong co gi doi thi khong apply(),
    // nen khong xep viec vao QueuedWork. Tra ve so key da ghi.
    fun putAllChanged(values: Map<String, Any>): Int {
        val changed = changedEntries(mSharedPreferences.all, values)
        if (changed.isEmpty()) return 0
        mSharedPreferences.edit {
            for ((key, value) in changed) {
                when (value) {
                    is String -> putString(key, value)
                    is Boolean -> putBoolean(key, value)
                    is Float -> putFloat(key, value)
                    is Int -> putInt(key, value)
                    is Long -> putLong(key, value)
                }
            }
        }
        return changed.size
    }

    protected fun clear() {
        mSharedPreferences.edit { clear() }
    }

    protected inner class SharedPreferenceProperty<T>(
        private val key: String,
        private val defaultValue: T,
    ) {
        private val clas: Class<T>
            get() = defaultValue!!::class.java as Class<T>

        operator fun getValue(
            thisRef: Any?,
            property: KProperty<*>,
        ): T {
            return try {
                when (defaultValue) {
                    is String -> {
                        mSharedPreferences.getString(key, defaultValue as String) as T
                    }

                    is Int -> {
                        mSharedPreferences.getInt(key, defaultValue as Int) as T
                    }

                    is Boolean -> {
                        mSharedPreferences.getBoolean(key, defaultValue as Boolean) as T
                    }

                    is Float -> {
                        mSharedPreferences.getFloat(key, defaultValue as Float) as T
                    }

                    is Double -> {
                        mSharedPreferences.getFloat(key, defaultValue as Float).toDouble() as T
                    }

                    is Long -> {
                        mSharedPreferences.getLong(key, defaultValue as Long) as T
                    }

                    is Set<*> -> {
                        mSharedPreferences.getStringSet(key, defaultValue as Set<String>) as T
                    }

                    is Enum<*> -> {
                        val enumName = mSharedPreferences.getString(key, "")
                        clas.enumConstants?.firstOrNull { (it as Enum<*>).name == enumName } ?: defaultValue
                    }

                    else -> {
                        val jsonData = mSharedPreferences.getString(key, null)
                        return if (jsonData != null) {
                            val type = object : TypeToken<T>() {}.type
                            Gson().fromJson<T>(jsonData, type)
                        } else {
                            defaultValue
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.tag(TAG).e("getValue: ${e.message}")
                defaultValue
            }
        }

        operator fun setValue(
            thisRef: Any?,
            property: KProperty<*>,
            value: T,
        ) {
            try {
                with(mSharedPreferences.edit()) {
                    when (value) {
                        is String -> {
                            putString(key, value)
                        }

                        is Int -> {
                            putInt(key, value)
                        }

                        is Boolean -> {
                            putBoolean(key, value)
                        }

                        is Float -> {
                            putFloat(key, value)
                        }

                        is Double -> {
                            putFloat(key, value.toFloat())
                        }

                        is Long -> {
                            putLong(key, value)
                        }

                        is Enum<*> -> {
                            putString(key, value.name)
                        }

                        is Set<*> -> {
                            putStringSet(key, value as Set<String>)
                        }

                        else -> {
                            val json = Gson().toJson(value)
                            putString(key, json)
                        }
                    }
                    apply()
                }
            } catch (e: Exception) {
                Timber.tag(TAG).e("setValue: ${e.message}")
            }
        }
    }
}
