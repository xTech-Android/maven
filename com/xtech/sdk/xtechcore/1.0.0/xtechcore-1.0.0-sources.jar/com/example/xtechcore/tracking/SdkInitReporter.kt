package com.example.xtechcore.tracking

// Core khong biet SdkInitTracker cua SDK nao -> SDK embed core tu gan hook (xtechads gan trong BaseAds.init).
// Khong gan thi core im lang, khong ban sdk_init. Set o main, doc o IO -> @Volatile.
object SdkInitReporter {
    @Volatile
    var onDone: ((key: String, startTime: Long, success: Boolean) -> Unit)? = null
}
