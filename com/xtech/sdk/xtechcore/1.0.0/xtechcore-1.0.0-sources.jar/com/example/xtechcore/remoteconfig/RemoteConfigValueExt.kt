package com.example.xtechcore.remoteconfig

import com.google.firebase.remoteconfig.FirebaseRemoteConfigValue

fun FirebaseRemoteConfigValue.isBoolean(): Boolean =
    try {
        this.asBoolean()
        true
    } catch (_: Exception) {
        false
    }

fun FirebaseRemoteConfigValue.isString(): Boolean =
    try {
        this.asString()
        true
    } catch (_: Exception) {
        false
    }

fun FirebaseRemoteConfigValue.isDouble(): Boolean =
    try {
        this.asDouble()
        true
    } catch (_: Exception) {
        false
    }

fun FirebaseRemoteConfigValue.isLong(): Boolean =
    try {
        this.asLong()
        true
    } catch (_: Exception) {
        false
    }
