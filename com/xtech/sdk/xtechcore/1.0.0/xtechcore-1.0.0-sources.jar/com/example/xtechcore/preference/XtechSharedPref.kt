package com.example.xtechcore.preference

import android.app.Application
import timber.log.Timber

// Chi giu key ma CODE CORE doc. Key cua tung SDK/app -> subclass tu khai
// (vd AdsSharedPref ben :xtechads), core khong biet key cua ai.
open class XtechSharedPref(
    val app: Application,
) : SharePreference(app) {
    init {
        Timber.tag(TAG).d("init: ")
    }

    var fetchedRemoteConfig: Boolean by SharedPreferenceProperty("fetchedRemoteConfig", false)
}
